<?php $__env->startComponent('mail::message'); ?>

Dear <?php echo e($data['name']); ?>,

<?php echo e($data['message']); ?>,


With regards!<br>
<?php echo e(config('app.name')); ?> Ethiopia<br>
+251992758586<br>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\surfiebackend\resources\views/emails/deactivation.blade.php ENDPATH**/ ?>