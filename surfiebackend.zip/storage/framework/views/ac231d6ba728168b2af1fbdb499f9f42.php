<?php $__env->startComponent('mail::message'); ?>

Dear <?php echo e($data['name']); ?>,

<?php echo e($data['greating']); ?>,<br>

<?php echo e($data['message']); ?>,<br>

<?php $__env->startComponent('mail::button', ['url' => 'https://afromina-digitals.com']); ?>
Visit Us
<?php echo $__env->renderComponent(); ?>

<?php echo e($data['footer']); ?>,
<br>




Kind Regards!<br>
<?php echo e(config('app.name')); ?> Ethiopia<br>
+251992758586<br>
surfieethiopia@gmail.com
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\surfiebackend\resources\views/emails/welcome.blade.php ENDPATH**/ ?>