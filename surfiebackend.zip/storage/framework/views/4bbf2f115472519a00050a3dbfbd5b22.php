<?php $__env->startComponent('mail::message'); ?>

Dear Customer,

<?php echo e($data['description']); ?>,

Thanks,<br>
<!-- <?php echo e(config('app.name')); ?> -->
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\surfiebackend\resources\views/emails/compose.blade.php ENDPATH**/ ?>