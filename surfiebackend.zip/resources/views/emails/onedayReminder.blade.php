Hello {{ $user->name }},

This is a reminder that your parental control subscription will end tommorrow!.

To avoid service disruption, please settle your payment today.

Check with customer support for further assistance.

Best regards,
Surfie Ethiopia
+251992758586

