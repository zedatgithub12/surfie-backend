<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\surfiebackend\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>