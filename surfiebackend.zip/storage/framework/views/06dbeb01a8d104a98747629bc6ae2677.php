<?php $__env->startComponent('mail::message'); ?>

Dear Customers, <br>

Click the button below to reset password

<?php $__env->startComponent('mail::button', ['url' => 'http://127.0.0.1:3000/reset-password/' . $data['token']]); ?>
Reset Password
<?php echo $__env->renderComponent(); ?>

If you did not request a password reset, you can ignore this email, <br>

Kind Regards!<br>
<?php echo e(config('app.name')); ?> Ethiopia<br>
+251992758586<br>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\surfiebackend\resources\views/emails/password_reset_link.blade.php ENDPATH**/ ?>